package com.example.botheat.service.impl;

import com.example.botheat.dao.OperatorDao;
import com.example.botheat.entity.Operator;
import com.example.botheat.service.OperatorService;
import com.example.botheat.util.AppException;
import com.example.botheat.util.PageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


/**
 * @author haya
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class OperatorServiceImpl implements OperatorService {

	@Autowired
	private OperatorDao operatorDao;

	@Override
	public void addOperator(Operator operator) {
		try {
			operatorDao.addOperator(operator);
		}catch(Exception e) {
			e.printStackTrace();
			throw new AppException("���ʧ��!");
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public PageModel findAllOperator(String queryString,
									 int pageNo, int pageSize) {
		try {
			return operatorDao.findAllOperator(queryString, pageNo, pageSize);
		}catch(Exception e) {
			e.printStackTrace();
			throw new AppException("��ҳ��ѯʧ��!");
		}
	}

	@Override
	public void modifyOperator(Operator operator) {
		try {
			operatorDao.modifyOperator(operator);
		}catch(Exception e) {
			e.printStackTrace();
			throw new AppException("�޸�ʧ��!");
		}
	}

	@Override
	public void delOperator(int[] operatorIds) {
		try {
			operatorDao.delOperator(operatorIds);
		}catch(Exception e) {
			e.printStackTrace();
			throw new AppException("ɾ��ʧ��!");
		}
	}

	@Override
	public Operator findOperatorById(int id) {
		try {
			return operatorDao.findOperatorById(id);
		}catch(Exception e) {
			e.printStackTrace();
			throw new AppException("��ѯʧ�ܣ�����=��" + id + "��!");
		}
	}

	public void setOperatorDao(OperatorDao operatorDao) {
		this.operatorDao = operatorDao;
	}
}
