package com.example.botheat.service;

import com.example.botheat.entity.Operator;
import com.example.botheat.util.PageModel;

/**
 * @author haya
 */
public interface OperatorService {

    void addOperator(Operator operator);

    void modifyOperator(Operator operator);

    void delOperator(int[] operatorIds);

    PageModel findAllOperator(String queryString, int pageNo, int pageSize);

    Operator findOperatorById(int id);
}
