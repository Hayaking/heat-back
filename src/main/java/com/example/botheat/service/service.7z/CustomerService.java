package com.example.botheat.service;

import com.example.botheat.entity.Customer;
import com.example.botheat.util.PageModel;

import java.util.List;
import java.util.Map;

/**
 * @author haya
 */
public interface CustomerService {

    void addCustomer(Customer customer);

    void modifyCustomer(Customer customer);

    void delCustomer(int[] customerIds);

    PageModel findAllCustomer(String queryString, int pageNo, int pageSize);

    Map<String, Customer> findCustomerMap();

    Customer findCustomerById(int id);

    List<String> findCustomerName();
}
