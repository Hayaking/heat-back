package com.example.botheat.net;


import com.example.botheat.entity.Customer;
import com.example.botheat.entity.HeatData;
import com.example.botheat.service.CustomerService;
import com.example.botheat.service.HeatDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author haya
 */
@Component
public class SocketServer {
	@Autowired
	private CustomerService customerService;
	@Autowired
	private HeatDataService heatDataService;

	private Map<String, Customer> customerMap;
	private Map<String, Socket> socketMap = new ConcurrentHashMap<>();
	private ServerSocket serverSocket;
	private boolean running = true;

	public SocketServer() {

	}

	public void start(){
		System.out.println(customerService);
		System.out.println(heatDataService);
		customerMap = customerService.findCustomerMap();
		Thread t1 = new Thread(new MainHandler());
		t1.start();
		Thread t2 = new Thread(new ClientHandler());
		t2.start();
	}

	public class MainHandler implements Runnable {
	     public MainHandler(){
 	         try {
				serverSocket = new ServerSocket(5005);
			} catch (IOException e) {
				e.printStackTrace();
			}
		 }

		 @Override
		 public void run() {
		     Socket clientSocket = null;
			 while (isRunning()) {
				try {
				    clientSocket = serverSocket.accept();
					clientSocket.setSoTimeout(5000);
					initComm(clientSocket);
				} catch (Exception ex) {
			        ex.printStackTrace();
		        }
		     }
	     }
		 private void initComm(Socket clientSocket){
		     String inStr = "";
			 String gprsId = "";
			 byte[] inData = new byte[45];
			 try{
			     DataInputStream input = new DataInputStream(clientSocket.getInputStream());
			     input.read(inData);
				 inStr = HexUtil.bytesToString(inData);
			     if (inStr.substring(0, 8).equals("FF0D0901")) {
			         gprsId = HexUtil.hexToASCII(inStr.substring(8, 30));
					 socketMap.put(gprsId, clientSocket);
				     System.out.println(">>[" +gprsId + "]");
			     }
			 } catch (Exception ex) {
			     ex.printStackTrace();
		     }
	     }
	}

	public class ClientHandler implements Runnable {
		private Socket clientSocket;
		private DataInputStream input;
		private DataOutputStream output;
		private byte[] inData = new byte[45];
		private byte[] outData = null;

		public ClientHandler() {
		}

		@Override
		public void run() {
	outer:while(isRunning()){
			for(String gprsId : socketMap.keySet()){
				try {
					clientSocket = socketMap.get(gprsId);
					input = new DataInputStream(clientSocket.getInputStream());
					output = new DataOutputStream(clientSocket.getOutputStream());

					initOutData(gprsId);
					output.write(outData, 0, outData.length);
					output.flush();
					try{
					    input.read(inData);
						String inStr = HexUtil.bytesToString(inData);
					    if (inStr.length() == 90 && HexUtil.crc16(inData).equals("0000")) {
							saveInData(inStr, gprsId);
						}
					}catch(SocketTimeoutException e){
						e.printStackTrace();
					}
					Thread.sleep(2000);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				if(!isRunning()) {
					break outer;
				}
			} // for
			try{
			    Thread.sleep(30000);
			}catch(Exception ex){
			    ex.printStackTrace();
			}
		  } // while
		} // run

		private String getAddr(String gprsId){
			String addr = Integer.toHexString(customerMap.get(gprsId).getAddr());
			if(addr.length()==1) {
				addr = "0"+addr;
			}
			return addr;
		}
		private String getCustName(String gprsId){
			return customerMap.get(gprsId).getCustName();
		}
		private synchronized void saveInData(String inStr, String gprsId) {
			HeatData heatData = new HeatData();
			heatData.setAddr(Integer.parseInt(getAddr(gprsId),16));
			heatData.setCustName(getCustName(gprsId));
			heatData.setFlow(HexUtil.hexStrToFloat(inStr.substring(6, 14)));
			heatData.setTemperature(HexUtil.hexStrToFloat(inStr.substring(14,
					22)));
			heatData
					.setPressure(HexUtil.hexStrToFloat(inStr.substring(22, 30)));
			heatData.setTotalFlow(HexUtil
					.hexStrToFloat(inStr.substring(62, 70)));
			heatData.setMonthFlow(HexUtil
					.hexStrToFloat(inStr.substring(70, 78)));
			heatData.setDayFlow(HexUtil.hexStrToFloat(inStr.substring(78, 86)));
			heatData.setAcquireTime(new Date());
			heatDataService.addHeatData(heatData);
			System.out.println("----------------------");
			System.out.println("手机号=" + gprsId);
			System.out.println("瞬时流量="
					+ HexUtil.hexStrToFloat(inStr.substring(6, 14)));
			System.out.println("温度="
					+ HexUtil.hexStrToFloat(inStr.substring(14, 22)));
			System.out.println("压力="
					+ HexUtil.hexStrToFloat(inStr.substring(22, 30)));
			System.out.println("总累计流量="
					+ HexUtil.hexStrToFloat(inStr.substring(62, 70)));
			System.out.println("月累计流量="
					+ HexUtil.hexStrToFloat(inStr.substring(70, 78)));
			System.out.println("日累计流量="
					+ HexUtil.hexStrToFloat(inStr.substring(78, 86)));
		}

		private void initOutData(String gprsId) {
			outData = HexUtil.stringToBytes(getAddr(gprsId) + "03000000140000");
			String crc = HexUtil.crc16(Arrays.copyOf(outData, 6));
			// CRC-L
			outData[6] = (byte) Integer.parseInt(crc.substring(2), 16);
			// CRC-H
			outData[7] = (byte) Integer.parseInt(crc.substring(0, 2), 16);
		}
	} // close inner class

	public void stop(){
		setRunning(false);
		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		for(Socket s :socketMap.values()){
			try {
				s.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public synchronized void setRunning(boolean running) {
        this.running = running;
    }
    public synchronized boolean isRunning() {
        return running;
    }

	public void setHeatDataService(HeatDataService heatDataService) {
		this.heatDataService = heatDataService;
	}

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}

}
