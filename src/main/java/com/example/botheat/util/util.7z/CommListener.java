package com.example.botheat.util;

import com.example.botheat.net.SocketServer;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * @author haya
 */
public class CommListener implements ServletContextListener {

	private SocketServer socketServer;

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		WebApplicationContext context = WebApplicationContextUtils.getRequiredWebApplicationContext(sce.getServletContext());
		this.socketServer = context.getBean( SocketServer.class );
		socketServer.start();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		socketServer.stop();
	}
}
