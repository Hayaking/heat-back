package com.example.botheat.util;

import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.log4j.BasicConfigurator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HBaseUtil {
    private static final String ZK_QUORUM = "hbase.zookeeper.quorum";
    private static final String ZK_CLIENTPORT = "hbase.zookeeper.property.clientPort";
    private static Connection conn;

    static {
        BasicConfigurator.configure();
        Configuration conf = HBaseConfiguration.create();
        conf.set( ZK_QUORUM, "222.22.91.215" );
        conf.set( ZK_CLIENTPORT, "2181" );
        try {
            conn = ConnectionFactory.createConnection( conf );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        return conn;
    }

    public static void close() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void put(String table_name, byte[] rowkey, String family, String qualifier, String value, long timestamp) {
        try {
            Table table = conn.getTable( TableName.valueOf( table_name ) );
            Put put = new Put( rowkey, timestamp );
            put.addColumn( family.getBytes(), qualifier.getBytes(), value.getBytes() );
            table.put( put );
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Cell> get(String table_name, byte[] rowkey, String family, String qualifier, long startDate, long endDate) {
        List<Cell> list = new ArrayList<Cell>();
        try {
            Table table = conn.getTable( TableName.valueOf( table_name ) );
            Get get = new Get( rowkey );
            if (StringUtils.isNotEmpty( family ) && StringUtils.isNotEmpty( qualifier )) {
                get.addColumn( family.getBytes(), qualifier.getBytes() );
            }
            if (StringUtils.isNotEmpty( family ) && StringUtils.isEmpty( qualifier )) {
                get.addFamily( family.getBytes() );
            }
            if (startDate != 0 && endDate == 0) {
                get.setTimeStamp( startDate );
            }
            if (startDate != 0 && endDate != 0) {
                get.setTimeRange( startDate, endDate );
            }

            Scan scan = new Scan( get );
            scan.setCaching( 1000 );
            scan.setMaxVersions();

            ResultScanner scanner = table.getScanner( scan );
            for (Result result : scanner) {
                Cell[] cells = result.rawCells();
                for (Cell cell : cells) {
                    list.add( cell );
                }
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<Cell> getByPage(String table_name, byte[] rowkey, String family, String qualifier, long startDate, long endDate, int pageSize) {
        List<Cell> list = new ArrayList<Cell>();
		try {
            Table table = conn.getTable( TableName.valueOf( table_name ) );
            Get get = new Get( rowkey );
            get.addColumn( Bytes.toBytes( family ), Bytes.toBytes( qualifier ) );

            get.setTimeRange( startDate, endDate );

            Scan scan = new Scan( get );
            scan.setCaching( pageSize );
            scan.setMaxVersions();

            int row = 0;
            ResultScanner scanner = table.getScanner( scan );
            for (Result result : scanner) {
                Cell[] cells = result.rawCells();
                for (Cell cell : cells) {
                    row++;
                    if (row > pageSize) {
                        break;
                    }
                    list.add( cell );
                }
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }

    public static List<Cell> scan(String table_name, String family, String qualifier) {
        short startRow = 1;
        return scan( table_name, family, qualifier, Bytes.toBytes( startRow ), null, 0, 0 );
    }

    public static List<Cell> scan(String table_name, String family, String qualifier, long startDate, long endDate) {
        short startRow = 1;
        return scan( table_name, family, qualifier, Bytes.toBytes( startRow ), null, startDate, endDate );
    }

    public static List<Cell> scan(String table_name, String family, String qualifier, byte[] startRow, byte[] endRow, long startDate, long endDate) {
        List<Cell> list = new ArrayList<Cell>();
        try {
            Table table = conn.getTable( TableName.valueOf( table_name ) );
            Scan scan = new Scan();
            scan.setCaching( 1000 );

            if (StringUtils.isNotBlank( family ) && StringUtils.isNotEmpty( qualifier )) {
                scan.addColumn( family.getBytes(), qualifier.getBytes() );
            }
            if (StringUtils.isNotEmpty( family ) && StringUtils.isEmpty( qualifier )) {
                scan.addFamily( family.getBytes() );
            }
            if (startRow != null) {
                scan.setStartRow( startRow );
            }
            if (startRow != null && endRow != null) {
                scan.setStopRow( endRow );
            }
            if (startDate != 0 && endDate == 0) {
                scan.setTimeStamp( startDate );
            }
            if (startDate != 0 && endDate != 0) {
                scan.setTimeRange( startDate, endDate );
            }

            ResultScanner scanner = table.getScanner( scan );
            for (Result result : scanner) {
                Cell[] cells = result.rawCells();
                for (Cell cell : cells) {
                    list.add( cell );
                }
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }


}
