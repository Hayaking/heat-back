package com.example.botheat.util;

import com.example.botheat.service.ChartService;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author haya
 */
public class ChartServlet extends HttpServlet {

    private static final long serialVersionUID = -1288964538929868311L;
    @Autowired
    private ChartService chartService;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        doPost( request, response );
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        request.setCharacterEncoding( "GBK" );
        Date startDate = new Date();
        Date endDate = new Date();


        String custName = request.getParameter( "custName" );
        String date = request.getParameter( "startDate" );
        try {
            if (date != null) {
                startDate = new SimpleDateFormat( "yyyy-MM-dd" ).parse( date );
                startDate = DateUtil.getDayStart( startDate );
            }
            endDate = DateUtil.getDayEnd( startDate );
        } catch (ParseException e) {
            e.printStackTrace();
        }
        ServletOutputStream out = response.getOutputStream();
        chartService = (ChartService)new ClassPathXmlApplicationContext("spring.xml")
                .getBean("chartServiceImpl");

        JFreeChart chart = chartService.createChart( custName, startDate, endDate );
        ChartUtilities.writeChartAsJPEG( out, chart, 800, 400 );
    }

}
