package com.example.botheat.dao.impl;

import com.example.botheat.dao.CustomerDao;
import com.example.botheat.entity.Customer;
import com.example.botheat.util.PageModel;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author haya
 */
public class CustomerDaoImpl extends HibernateDaoSupport implements CustomerDao {

    @Resource
    protected SessionFactory sessionFactory;
    @Resource
    protected HibernateTemplate hibernateTemplate;

    @Resource
    public void setmySessionFactory(SessionFactory sessionFactory) {
        super.setSessionFactory( sessionFactory );
    }

    @Override
    public void addCustomer(Customer customer) {
        getHibernateTemplate().save( customer );
    }

    @Override
    public void modifyCustomer(Customer customer) {
        getHibernateTemplate().update( customer );
    }

    @Override
    public void delCustomer(int[] customerIds) {
        for (int customerId : customerIds) {
            getHibernateTemplate().delete(
                    getHibernateTemplate().load( Customer.class, customerId )
            );
        }
    }

    @Override
    public Customer findCustomerById(int id) {
        return getHibernateTemplate().load( Customer.class, id );
    }


    @Override
    public PageModel findAllCustomer(final String queryString, final int pageNo, final int pageSize) {
        List customerList;
        if (queryString != null && !"".equals( queryString )) {
            customerList = (List) getHibernateTemplate()
                    .execute( (HibernateCallback) session ->
                            session.createQuery( "from Customer c where c.addr = ? or c.custName like ? order by c.addr" )
                                    .setParameter( 0, queryString )
                                    .setParameter( 1, "%" + queryString + "%" )
                                    .setFirstResult( (pageNo - 1) * pageSize )
                                    .setMaxResults( pageSize )
                                    .list() );
        } else {
            customerList = (List) getHibernateTemplate()
                    .execute( (HibernateCallback) session -> session.createQuery( "from Customer c order by c.addr" )
                            .setFirstResult( (pageNo - 1) * pageSize )
                            .setMaxResults( pageSize )
                            .list() );
        }
        PageModel pageModel = new PageModel();
        pageModel.setPageNo( pageNo );
        pageModel.setPageSize( pageSize );
        pageModel.setList( customerList );
        pageModel.setTotalRecords( getTotalRecords( queryString ) );
        return pageModel;
    }

    @Override
    public Customer findCustomerByName(String custName) {
        //默认是id为1的用户
        Customer c = findCustomerById( 1 );
        List list = getHibernateTemplate().find( "from Customer c where c.custName='" + custName + "'" );
        if (list.size() > 0) {
            c = (Customer) list.get( 0 );
        }
        return c;
    }

    @Override
    public Customer findCustomerByAddr(int addr) {
        return (Customer) getHibernateTemplate().find( "from Customer c where c.addr=" + addr ).get( 0 );
    }


    private int getTotalRecords(String queryString) {
        List list;
        if (queryString != null && !"".equals( queryString )) {
            list = getHibernateTemplate().find( "select count(id) from Customer c where c.addr = ? or c.custName like ?",
                    queryString, "%" + queryString + "%" );
        } else {
            list = getHibernateTemplate().find( "select count(id) from Customer" );
        }
        return ((Long) list.get( 0 )).intValue();

    }

}
