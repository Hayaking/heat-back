package com.example.botheat.dao.impl;

import com.example.botheat.dao.OperatorDao;
import com.example.botheat.entity.Operator;
import com.example.botheat.util.PageModel;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.HibernateCallback;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author haya
 */
@Component
public class OperatorDaoImpl extends HibernateDaoSupport implements OperatorDao {

    @Resource
    protected SessionFactory sessionFactory;
    @Resource
    protected HibernateTemplate hibernateTemplate;

    @Resource
    public void setmySessionFactory(SessionFactory sessionFactory) {
        super.setSessionFactory( sessionFactory );
    }


    @Override
    public void addOperator(Operator operator) {
        getHibernateTemplate().save( operator );
    }

    @Override
    public void modifyOperator(Operator operator) {
        getHibernateTemplate().update( operator );
    }

    @Override
    public void delOperator(int[] operatorIds) {
        for (int i = 0; i < operatorIds.length; i++) {
            getHibernateTemplate().delete(
                    getHibernateTemplate().load( Operator.class, operatorIds[i] )
            );
        }
    }

    @Override
    public Operator findOperatorById(int id) {
        return getHibernateTemplate().load( Operator.class, id );
    }

    @Override
    public PageModel findAllOperator(final String queryString,
                                     final int pageNo, final int pageSize) {
        List operatorList;
        if (queryString != null && !"".equals( queryString )) {
            operatorList = (List) getHibernateTemplate().execute( (HibernateCallback) session -> session.createQuery( "from Operator o where o.username like ?" )
                    .setParameter( 0, "%" + queryString + "%" )
                    .setFirstResult( (pageNo - 1) * pageSize )
                    .setMaxResults( pageSize )
                    .list() );


        } else {
            operatorList = (List) getHibernateTemplate().execute( (HibernateCallback) session -> session.createQuery( "from Operator" )
                    .setFirstResult( (pageNo - 1) * pageSize )
                    .setMaxResults( pageSize )
                    .list() );
        }
        PageModel pageModel = new PageModel();
        pageModel.setPageNo( pageNo );
        pageModel.setPageSize( pageSize );
        pageModel.setList( operatorList );
        pageModel.setTotalRecords( getTotalRecords( queryString ) );
        return pageModel;
    }

    private int getTotalRecords(String queryString) {

        List list;
        if (queryString != null && !"".equals( queryString )) {
            list = getHibernateTemplate().find( "select count(id) from Operator o where o.username like ?",
					"%" + queryString + "%" );
        } else {
            list = getHibernateTemplate().find( "select count(id) from Operator" );
        }
        return ((Long) list.get( 0 )).intValue();

    }

}
