package com.example.botheat.dao.impl;

import com.example.botheat.dao.HeatDataDao;
import com.example.botheat.entity.HeatData;
import com.example.botheat.util.PageModel2;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author haya
 */

public class HeatDataDaoImpl extends HibernateDaoSupport implements HeatDataDao {
    @Resource
    protected SessionFactory sessionFactory;
    @Resource
    protected HibernateTemplate hibernateTemplate;
    @Resource
    public void setmySessionFactory(SessionFactory sessionFactory) {
        super.setSessionFactory(sessionFactory);
    }
    @Override
    public void addHeatData(HeatData heatData) {
        this.getHibernateTemplate().save( heatData );
    }

    @Override

    public void modifyHeatData(HeatData heatData) {
        getHibernateTemplate().update( heatData );
    }

    @Override

    public void delHeatData(int[] heatDataIds) {
        for (int i = 0; i < heatDataIds.length; i++) {
            getHibernateTemplate().delete(
                    getHibernateTemplate().load( HeatData.class, heatDataIds[i] )
            );
        }
    }

    @Override

    public HeatData findHeatDataById(int id) {
        return getHibernateTemplate().load( HeatData.class, id );
    }

    @Override
    public PageModel2<HeatData> findAllHeatData(final String custName, final Date startDate, final Date endDate,
                                                final int pageNo, final int pageSize) {

        return null;
    }

    private int getTotalRecords(String custName, Date startDate, Date endDate) {

        List list = new ArrayList();
        if (custName != null && !"".equals( custName )) {
            list = getHibernateTemplate().find( "select count(id) from HeatData h where h.custName = ? and h.acquireTime between ? and ?",
                    custName, startDate, endDate );
        } else {
            list = getHibernateTemplate().find( "select count(id) from HeatData" );
        }
        return ((Long) list.get( 0 )).intValue();

    }

    @Override
    public List<HeatData> findLatestHeatData() {
        return (List<HeatData>) getHibernateTemplate().find( "from HeatData h where h.id in ("
                + "select max(id) from HeatData group by addr) order by h.addr" );
    }

    @Override
    public List<HeatData> findReport(Date startDate, Date endDate) {
        return (List<HeatData>) getHibernateTemplate().find( "from HeatData h where h.id in ("
                        + "select max(id) from HeatData where acquireTime between ? and ? group by addr) order by h.addr",
                new Object[]{startDate, endDate} );
    }

}
