package com.example.botheat.dao.impl;

import com.example.botheat.dao.CustomerDao;
import com.example.botheat.dao.HeatDataDao;
import com.example.botheat.entity.HeatData;
import com.example.botheat.util.DateUtil;
import com.example.botheat.util.HBaseUtil;
import com.example.botheat.util.PageModel2;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.util.Bytes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HeatDataDaoImpl2 implements HeatDataDao {
    private CustomerDao customerDao;

	private String table_name = "heat";
    private String family = "cf";
    private String qualifier = "v";

	@Override
	public void addHeatData(HeatData heatData) {
		byte[] rowkey = Bytes.toBytes((short)heatData.getAddr());
		String value = getHeatV(heatData);
		long timestamp = heatData.getAcquireTime().getTime();
		HBaseUtil.put(table_name, rowkey, family, qualifier, value, timestamp);
	}

	@Override
	public PageModel2<HeatData> findAllHeatData(String custName, Date startDate, Date endDate, int pageNo, int pageSize) {

		int addr = customerDao.findCustomerByName(custName).getAddr();
		byte[] rowkey = Bytes.toBytes((short)addr);
		long lastTime = startDate.getTime();
		long endTime = endDate.getTime();

		List<HeatData> heatDataList = new ArrayList<>();
		List<Cell> cells = HBaseUtil.getByPage(table_name, rowkey, family, qualifier, lastTime, endTime, pageSize);
	    for(Cell cell : cells) {
		    String rowkey_ =  Bytes.toHex(CellUtil.cloneRow(cell));
		    String value = Bytes.toString(CellUtil.cloneValue(cell));
		    long ts = cell.getTimestamp();
		    heatDataList.add(getHeatData(rowkey_, ts, value));
	    }
		PageModel2 pageModel = new PageModel2();
		pageModel.setPageNo(pageNo);
		pageModel.setPageSize(pageSize);
		pageModel.setList(heatDataList);
		if(heatDataList.size()>0){
		    //��1000������Ϊ��һҳ������
			pageModel.setLastRow( DateUtil.format(heatDataList.get(heatDataList.size()-1).getAcquireTime().getTime()-1000));
			 //��1000��ʹ��scan����β��
			pageModel.setFirstRow(DateUtil.format(heatDataList.get(0).getAcquireTime().getTime()+1000));
		}
		return pageModel;
	}

	@Override
	public List<HeatData> findLatestHeatData() {
	    List<HeatData> heatDataList = new ArrayList<HeatData>();

		List<Cell> cells = HBaseUtil.scan(table_name, family, qualifier);
		for(Cell cell : cells) {
	        String rowkey =  Bytes.toHex(CellUtil.cloneRow(cell));
			String value = Bytes.toString(CellUtil.cloneValue(cell));
			long ts = cell.getTimestamp();
			heatDataList.add(getHeatData(rowkey, ts, value));
		}
		return heatDataList;
	}

	@Override
	public List<HeatData> findReport(Date startDate, Date endDate) {
	    List<HeatData> heatDataList = new ArrayList<HeatData>();

		List<Cell> cells = HBaseUtil.scan(table_name, family, qualifier, startDate.getTime(), endDate.getTime());
		for(Cell cell : cells) {
	        String rowkey =  Bytes.toHex(CellUtil.cloneRow(cell));
			String value = Bytes.toString(CellUtil.cloneValue(cell));
			long ts = cell.getTimestamp();
			heatDataList.add(getHeatData(rowkey, ts, value));
		}
		return heatDataList;
	}

	@Override
	public HeatData findHeatDataById(int id) {
		System.out.println("û��ʵ��findHeatDataById()����");
		return null;
	}

	@Override
	public void modifyHeatData(HeatData heatData) {
		System.out.println("û��ʵ��modifyHeatData()����");
	}

	@Override
	public void delHeatData(int[] HeatDataIds) {
		System.out.println("û��ʵ��delHeatData()����");
	}

	public String getHeatV(HeatData h){
		return "["+h.getTemperature()+","+h.getPressure()+","+h.getFlow()+","
		          +h.getTotalFlow()+","+h.getMonthFlow()+","+h.getDayFlow()+"]";
	}

	public HeatData getHeatData(String addr, long acquireTime, String value){
		HeatData h = new HeatData();

		h.setAddr(Integer.parseInt(addr, 16));
		h.setAcquireTime(new Date(acquireTime));

		value = value.substring(1, value.length()-1);
		String[] arr = value.split(",");
		h.setTemperature(Double.parseDouble(arr[0]));
		h.setPressure(Double.parseDouble(arr[1]));
		h.setFlow(Double.parseDouble(arr[2]));
		h.setTotalFlow(Double.parseDouble(arr[3]));
		h.setMonthFlow(Double.parseDouble(arr[4]));
		h.setDayFlow(Double.parseDouble(arr[5]));

		String custName = customerDao.findCustomerByAddr(h.getAddr()).getCustName();
		h.setCustName(custName);
		return h;
	}

	public CustomerDao getCustomerDao() {
		return customerDao;
	}

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}


}
