package com.example.botheat.dao;

import com.example.botheat.entity.Customer;
import com.example.botheat.util.PageModel;

/**
 * @author haya
 */
public interface CustomerDao  {

    void addCustomer(Customer customer);

    void modifyCustomer(Customer customer);

    void delCustomer(int[] customerIds);

    Customer findCustomerById(int id);

    PageModel<Customer> findAllCustomer(String queryString, int pageNo, int pageSize);

    Customer findCustomerByName(String custName);

    Customer findCustomerByAddr(int addr);

}
