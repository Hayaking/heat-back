package com.example.botheat.dao;

import com.example.botheat.entity.Operator;
import com.example.botheat.util.PageModel;

/**
 * @author haya
 */
public interface OperatorDao {

    void addOperator(Operator operator);

    void modifyOperator(Operator operator);

    void delOperator(int[] operatorIds);

    Operator findOperatorById(int id);

    PageModel<Operator> findAllOperator(String queryString, int pageNo, int pageSize);

}
