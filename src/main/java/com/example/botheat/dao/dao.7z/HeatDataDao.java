package com.example.botheat.dao;

import com.example.botheat.entity.HeatData;
import com.example.botheat.util.PageModel2;

import java.util.Date;
import java.util.List;

/**
 * @author haya
 */
public interface HeatDataDao {

    void addHeatData(HeatData heatData);

    void modifyHeatData(HeatData heatData);

    void delHeatData(int[] HeatDataIds);

    HeatData findHeatDataById(int id);

    PageModel2<HeatData> findAllHeatData(String custName, Date startDate, Date endDate, int pageNo, int pageSize);

    List<HeatData> findLatestHeatData();

    List<HeatData> findReport(Date startDate, Date endDate);
}
